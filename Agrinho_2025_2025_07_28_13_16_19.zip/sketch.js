let player;
let targetX, targetY; // onde o jogador clicou
let moving = false;
let item;
let gameStarted = false; // controle da introdução

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(20);
  player = new Player();
  targetX = player.x;
  targetY = player.y;
  item = new Item(random(50, width - 50), random(50, height - 50));
}

function draw() {
  background("green");

  if (!gameStarted) {
    showIntro();
    return; // não desenha o jogo até clicar para iniciar o jogo
  }

  if (moving) {
    player.moveTo(targetX, targetY);
  }

  player.display();
  item.display();

  if (item.active && player.collidesWith(item)) {
    item.collect();
  }
}

function mousePressed() { // detequita quando o mause for precionado
  if (!gameStarted) {
    gameStarted = true; // começa o jogo
  } else {
    targetX = mouseX;
    targetY = mouseY;
    moving = true;
  }
}


// INTRODUÇÃO

function showIntro() {
  fill(0);
  textSize(36);
  text("Cenoura Express🥕", width / 2, height / 2 - 40);
  textSize(20);
  text("Como jogar: -clique na tela para se movimentar", width / 2, height / 2 + 10);
  textSize(20);
  text("                           -e colete a cenoura para ganhar o jogo", width / 2, height / 2 + 30);
}


// JOGADOR

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 32;
    this.speed = 3;
    this.emoji = '👨🏼‍🌾';
  }

  moveTo(tx, ty) { // move o jogador para tx e ty com uma certa velocidade
    let dx = tx - this.x;
    let dy = ty - this.y;
    let distance = dist(this.x, this.y, tx, ty);

    if (distance > 1) { 
      this.x += (dx / distance) * this.speed;
      this.y += (dy / distance) * this.speed;
    } else {
      this.x = tx;
      this.y = ty;
      moving = false;
    }
  }

  display() { // cria a figura de um fazendeiro em formato de emoji
    text(this.emoji, this.x, this.y);
  }

  collidesWith(item) { // calcula a distância entre o jogador e a cenoura
    let d = dist(this.x, this.y, item.x, item.y);
    return d < this.size;
  }
}

// ITEM

class Item {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 16;
    this.active = true;
    this.emoji = '🥕';
  }

  display() { // ira criar a cenoura
    if (this.active) {
      text(this.emoji, this.x, this.y);
    }
  }

  collect() { // vai desativar o item e mandar uma mensagem para o console.log
    this.active = false;
    console.log("Item coletado!"); 
  }
}

